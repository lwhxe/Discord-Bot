# Discord general-purpose bot
This will be covering:
* how to install.
* how to run.
* how it works.
